<?php

namespace App\Http\Controllers;

use App\Models\Apk;
use App\Http\Requests\StoreApkRequest;
use App\Http\Requests\UpdateApkRequest;

class ApkController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreApkRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Apk $apk)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Apk $apk)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateApkRequest $request, Apk $apk)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Apk $apk)
    {
        //
    }
}
