<?php

namespace App\Http\Controllers;

use App\Models\Kategoridiklat;
use App\Http\Requests\StoreKategoridiklatRequest;
use App\Http\Requests\UpdateKategoridiklatRequest;

class KategoridiklatController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreKategoridiklatRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Kategoridiklat $kategoridiklat)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Kategoridiklat $kategoridiklat)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateKategoridiklatRequest $request, Kategoridiklat $kategoridiklat)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Kategoridiklat $kategoridiklat)
    {
        //
    }
}
