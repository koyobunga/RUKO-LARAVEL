<?php

namespace App\Http\Controllers;

use App\Models\Rekom_sesuai;
use App\Http\Requests\StoreRekom_sesuaiRequest;
use App\Http\Requests\UpdateRekom_sesuaiRequest;

class RekomSesuaiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreRekom_sesuaiRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Rekom_sesuai $rekom_sesuai)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Rekom_sesuai $rekom_sesuai)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateRekom_sesuaiRequest $request, Rekom_sesuai $rekom_sesuai)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Rekom_sesuai $rekom_sesuai)
    {
        //
    }
}
