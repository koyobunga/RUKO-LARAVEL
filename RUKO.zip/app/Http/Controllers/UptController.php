<?php

namespace App\Http\Controllers;

use App\Models\Upt;
use App\Http\Requests\StoreUptRequest;
use App\Http\Requests\UpdateUptRequest;

class UptController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUptRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Upt $upt)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Upt $upt)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUptRequest $request, Upt $upt)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Upt $upt)
    {
        //
    }
}
