<link rel="stylesheet" type="text/css" href="{{ url('mobiles/styles/bootstrap.css') }}">
<link rel="stylesheet" type="text/css" href="{{ url('mobiles/styles/style.css') }}">
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="{{ url('mobiles/fonts/css/fontawesome-all.min.css') }}">    

<script type="text/javascript" src="{{ url('mobiles/scripts/jquery.js') }}"></script>
<script type="text/javascript" src="{{ url('mobiles/scripts/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ url('mobiles/scripts/custom.js') }}"></script>

