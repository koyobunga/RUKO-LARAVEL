@include('mobile.asset')

<div class="page-content">
        
    
    <div class="page-title page-title-small">
        <div class="mt-4 text-white font-500 font-17">{{ $asn->nama }}</div>
        <a href="#"  style="width: 50px; height: 50px;" data-menu="menu-main" class="bg-fade-gray1-dark shadow-xl preload-img" data-src="{{ url($asn->foto) }}"></a>
        {{-- <a href="#" style="width: 50px; height: 50px;" data-menu="menu-main" class="bg-fade-gray1-dark shadow-xl preload-img" data-src="{{ url('img/icon/rr_white.png') }}"></a> --}}
    </div>
    <div class="page-title font-11 text-light pr-5 line-height-s" style="margin-top: -25px">{{ $asn->opd->nama }}</div>
    <div class="card header-card shape-rounded" data-card-height="210">
        <div class="card-overlay bg-highlight opacity-95"></div>
        <div class="card-overlay dark-mode-tint"></div>
        <div class="card-bg bg-20"></div>
    </div>
    

    <!-- Homepage Slider-->
    <div class="single-slider-boxed text-center owl-no-dots owl-carousel">
        
            <div class="card rounded-l shadow-l" data-card-height="230">
                <div class="card-bottom">
                    <h2 class="font-700">Capain {{ $jp_th }} JP</h2>
                    <p class="boxed-text-xl fw-bold">
                        <div class="font-15 color-highlight">Capaian JP Tahunan</div>
                        <div class="font-15 color-highlight" style="margin-top: -5px">Tahun {{ $tahun }}</div>
                    </p>
                </div>
                
                <div class="card-overlay bg-gradient-fade"></div>
                <div class="card-bg owl-lazy" data-src="{{ url('mobiles/images/pictures/17m.jpg') }}"></div>
            </div>

            <div class="card rounded-l shadow-l" data-card-height="230">
                <div class="card-bottom">
                    <h2 class="font-700">Capaian {{ $jp_all }} JP</h2>
                    <p class="boxed-text-xl">
                        <div class="font-15 color-highlight">Semua JP yang telah dilaksanakan</div>
                    </p>
                </div>
                
                <div class="card-overlay bg-gradient-fade"></div>
                <div class="card-bg owl-lazy" data-src="{{ url('mobiles/images/pictures/24m.jpg') }}"></div>
            </div>

            <div class="card rounded-l shadow-l" data-card-height="230">
                <div class="card-bottom">
                    <h2 class="font-700">Realisasi {{ $persen_rencana }} %</h2>
                    <p class="boxed-text-xl fw-bold">
                        <div class="font-15 color-highlight">Realisasi Rencana Kompetensi {{ $tahun }}</div>
                        <div class="font-15 color-highlight font-500" style="margin-top: -5px">{{ $realisasi.'/'.$tot_rencana }}</div>
                    </p>
                </div>
                
                <div class="card-overlay bg-gradient-fade"></div>
                <div class="card-bg owl-lazy" data-src="{{ url('mobiles/images/pictures/13m.jpg') }}"></div>
            </div>
        
    </div>


    <div class="card card-style">
        <div class="content mb-2">
            <h5>Analisis Kebutuhan Diklat</h5>
            <p style="line-height: 120%">
                Dimaksudkan agar kegiatan diklat tepat sasaran antara peserta dengan program yang akan dijalankan.
            </p>

            <div class="list-group list-custom-small mt-0">
                @foreach ($akd as $a)
                <a href="#">
                    <i class="fas font-14 fa-chevron-right rounded-xl"></i>
                    <span>{{ $a['label'] }}</span>
                    <span class="badge bg-warning font-11">{{ $a['gap'] }}</span>
                    <i class="fa fa-angle-right"></i>
                </a>
                @endforeach
            </div>
            <button onclick="getHtml('{{ url('mobile/akd') }}')" class="btn btn-xs w-100 rounded-xl bg-highlight btn-full mt-3 mb-2">MENGISI AKD</button>
        </div>  
    </div>
        

    <div class="card bg-20 mt-4">
        <div class="card-body">
                 <h5 class="float-left color-white">Jadwal Diklat</h5>
                 <a class="float-right text-warning" onclick="getHtml('{{ url('mobile/jadwal') }}')" href="#">View All</a>
                 <div class="clearfix"></div>
            <p class="color-white">
                Temukan Jadwal Diklat
            </p>
            <div class="card card-slider card-style px-0 mx-0">
            
                <div class="single-slider slider-boxed owl-carousel owl-no-dots mt-3">
                    @foreach ($jadwal as  $j)
                        <p class="text-center font-15 font-500 line-height-m mt-3 pb-0">
                            {{ $j->diklat->nama }}
                            <br><br>
                            <span class="font-13 color-blue2-dark mt-3">{{ date('d F Y', strtotime($j->tgl_mulai)).' s.d '.date('d F Y', strtotime($j->tgl_selesai)) }}</span>
                            <br><span class="font-13 color-green1-dark">{{ $j->tempat }}</span>
                            <br><span class="font-13 color-brown1-dark">{{ $j->pelaksana }}</span>
                            <br><span class="font-13 color-red2-dark">{{ $j->jenis }}</span>
                        </p>
                    @endforeach
                </div>            
            </div>
        </div>
        <div class="card-overlay bg-highlight opacity-80"></div>
        <div class="card-overlay dark-mode-tint"></div>
    </div>
    
   
</div> 
    
